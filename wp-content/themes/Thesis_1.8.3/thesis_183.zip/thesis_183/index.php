<?php
/**
 * Cue the star of the show...
 *
 * @package Thesis
 */
if (! defined('ABSPATH'))
	die('Do not access this file directly.');

thesis_html_framework();
?>