<?php

// Using hooks is absolutely the smartest, most bulletproof way to implement things like plugins,
// custom design elements, and ads. You can add your hook calls below, and they should take the 
// following form:
// add_action('thesis_hook_name', 'function_name');
// The function you name above will run at the location of the specified hook. The example
// hook below demonstrates how you can insert Thesis' default recent posts widget above
// the content in Sidebar 1:
// add_action('thesis_hook_before_sidebar_1', 'thesis_widget_recent_posts');

// Delete this line, including the dashes to the left, and add your hooks in its place.

/**
 * function custom_bookmark_links() - outputs an HTML list of bookmarking links
 * NOTE: This only works when called from inside the WordPress loop!
 * SECOND NOTE: This is really just a sample function to show you how to use custom functions!
 *
 * @since 1.0
 * @global object $post
*/

require_once('admin/skin_options.php');
require_once('admin/widgets.php');

function global_imports() { ?>
	<link href="http://fonts.googleapis.com/css?family=Arvo:regular" rel="stylesheet" type="text/css" />
<?php }
	add_action('wp_head', 'global_imports');


/*-------------------------------------------------------------------------------------------------------
   HEADER
-------------------------------------------------------------------------------------------------------*/

function before_header() { ?>
	<div id="before">
<?php }
	add_action('thesis_hook_before_header', 'before_header');


function after_header() { ?>
	</div>
<?php }
	add_action('thesis_hook_after_header', 'after_header', 1);


function aff_banner() { global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } { ?>
	<?php if($mar_header_ad_toggle != "false") { ?>
		<?php echo '<a id="aff_banner" href="' . $mar_header_aff_url . '"><img src="' . $mar_header_aff_banner . '" alt="Recommended Product" /></a>'; ?>
	<?php } ?>
<?php } }
	add_action('thesis_hook_before_title', 'aff_banner');


function optin() { global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } { if(is_front_page()) { ?>
	<div class="optin head">
		<?php if($mar_header_optin_toggle != "true") { ?>
			<?php include('paste_optin.inc'); ?>
		<?php } ?>
		<div class="desc">
			<?php echo "<h3>" . stripslashes($mar_headline) . "</h3>" . "<h4>" . stripslashes($mar_subheadline) . "</h4>" . "<p>" . stripslashes($mar_desc) . "</p>"; ?>
		</div>
	</div>
<?php } } }
	add_action('thesis_hook_after_header', 'optin', 2);


function breadcrumb() { if (!is_front_page()) {
	echo '<p id="breadcrumb"><a href="';
	echo get_option('home');
	echo '">';
	bloginfo('name');
	echo "</a> &rarr; ";
	if (is_category() || is_single()) {
		the_category('title_li=');
		if (is_single()) {
			echo " &rarr; ";
			the_title();
		}
	} elseif (is_page()) {
		echo the_title();
	}
	echo '</p>';
} }
	add_action('thesis_hook_after_header', 'breadcrumb');


function feature_box() { ?>
	<ul>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Feature Box Column 1') ){ ?>
		<li>
			<h3>Custom Widget 1</h3>
			<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Feature Box Column 1</em></p>
		</li>		
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Feature Box Column 2') ){ ?>
		<li>
			<h3>Custom Widget 2</h3>
			<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Feature Box Column 2</em></p>
		</li>			
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Feature Box Column 3') ){ ?>
		<li class="last">
			<h3>Custom Widget 3</h3>
			<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Feature Box Column 3</em></p>
		</li>			
		<? } ?>
	</ul>
<?php }
	add_action('thesis_hook_feature_box', 'feature_box');
	register_sidebar(array('name'=>'Feature Box Column 1', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>',));
	register_sidebar(array('name'=>'Feature Box Column 2', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>',));
	register_sidebar(array('name'=>'Feature Box Column 3', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li class="last">', 'after_widget'  => '</li>',));


/*-------------------------------------------------------------------------------------------------------
   CONTENT
-------------------------------------------------------------------------------------------------------*/

function content_optin() { global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } { if(!is_single()) { ?>
	<?php if($mar_content_optin_toggle != "true") { ?>
		<div class="optin">
			<?php include('paste_optin.inc'); ?>
			<div class="desc">
				<?php echo "<h3>" . $mar_headline . "</h3>" . "<h4>" . $mar_subheadline . "</h4>" . "<p>" . $mar_desc . "</p>"; ?>
			</div>
		</div>
	<?php } ?>
<?php } } }
	add_action('thesis_hook_after_content', 'content_optin');


remove_action('thesis_hook_after_post', 'thesis_comments_link');


function singleNav() { if (is_single()) { ?>
	<ul id="singlenav">
		<li id="previous"><?php previous_post_link('<h5>&larr; Previous Article</h5> %link') ?></li>
		<li id="next"><?php next_post_link('<h5>Next Article &rarr;</h5> %link') ?></li>
	</ul>
<?php } }
	add_action('thesis_hook_after_content', 'singleNav');
	remove_action('thesis_hook_after_content', 'thesis_prev_next_posts');


/*-------------------------------------------------------------------------------------------------------
   SIDEBAR
-------------------------------------------------------------------------------------------------------*/

function sidebar_products() { global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } ?>
	<?php if($mar_products_toggle != "false") { ?>
		<div id="feat_products">
			<?php echo "<h3>" . $mar_listing_title . "</h3>" . "<span>" . $mar_listing_sub_title . "</span>"; ?>
			<ul>
				<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Featured Sidebar Products') ){ ?><? } ?>
			</ul>
		</div>
	<?php } ?>

	<?php if($mar_single_optin_toggle != "true") { if(is_single() || is_page()) { ?>	
		<div id="single_optin">
			<?php echo "<h3>" . $mar_headline . "</h3>" . "<h4>" . $mar_subheadline . "</h4>" . "<p>" . $mar_desc . "</p>"; ?>
			<?php include('paste_optin.inc'); ?>
		</div>
	<?php } } ?>
<?php }
	add_action('thesis_hook_before_sidebars', 'sidebar_products');
	register_sidebar(array('name'=>'Featured Sidebar Products', 'before_title' => '<h5>', 'after_title' => '</h5>', 'before_widget' => '<li>', 'after_widget'  => '</li>',));


/*-------------------------------------------------------------------------------------------------------
   FOOTER
-------------------------------------------------------------------------------------------------------*/

function footer() { ?>
	<ul>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 1') ){ ?>
		<li>
			<h3>Custom Widget 1</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 1</em></p>
		</li>
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 2') ){ ?>
		<li>
			<h3>Custom Widget 2</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 2</em></p>
		</li>		
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 3') ){ ?>
		<li class="last">
			<h3>Custom Widget 3</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 3</em></p>
		</li>		
		<? } ?>
	</ul>
	<div id="copyright">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Copyright') ){ ?>
		<p>Enter your own copyright text here using a <em>text widget</em>.</p>
		<? } ?>
		<!-- Make sure you have the proper licensing before deleting either copyrights -->
		<p>Built on <a href="http://diythemes.com/thesis/">Thesis</a>. <a href="http://kolakube.com/">Thesis skins by Kolakube</a></p>
		<!-- / Make sure you have the proper licensing before deleting either copyrights -->
	</div>
<?php }
	add_action('thesis_hook_footer', 'footer');
	remove_action('thesis_hook_footer', 'thesis_attribution');
	register_sidebar(array('name'=>'Footer Column 1', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Column 2', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Column 3', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li class="last">', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Copyright', 'before_widget' => '', 'after_widget'  => ''));

?>