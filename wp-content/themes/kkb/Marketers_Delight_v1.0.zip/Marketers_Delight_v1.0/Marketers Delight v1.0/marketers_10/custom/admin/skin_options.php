<?php
	$themename = "Marketers Delight";
	$skin_version = "1.0";
	$shortname = "mar";
	$skin_author = "Alex Mangini, ";
	$author_url = "<a href='http://kolakube.com/'>Kolakube</a>";
	$logo_path = "/custom/admin/images/marketers_logo.png";
	$options = array (
	
		// COLOR SWITCHER
		
		array(  "type" => "title",
				"name" => "Color Options",
				"desc" => "Choose a new color scheme for your blog."),
		
		array(	"type" => "row-open"),
		array(  "id" => $shortname."_appearance_theme",
				"options" => array("Red [Default]", "Orange", "Blue", "Green"),
				"std" => "Red [Default]",
				"type" => "select"),
		array(	"type" => "close"),


		// HEADER AD
		
		array(  "type" => "title",
				"name" => "Header Banner Management",
				"desc" => "Edit your affiliate banner in the header."),


		array(	"type" => "row-open"),
		array(	"type" => "col-open"),
		array(	"name" => "Affiliate Link",  
				"id" => $shortname."_header_aff_url",  
				"type" => "text",  
				"std" => "http://kolakube.com/"),
		array(	"type" => "close"),


		array(	"type" => "col-open"),
		array(	"name" => "Banner URL",  
				"id" => $shortname."_header_aff_banner",  
				"type" => "text",  
				"std" => get_bloginfo(template_directory)."/custom/admin/default/banner.png"),
		array(	"type" => "close"),
		array(	"type" => "close"),


		array(	"type" => "row-last-open"),
		array(	"type" => "col-open"),
		array( 	"desc" => "Enable Header Ad",
				"id" => $shortname."_header_ad_toggle",
				"std" => "false",
				"type" => "checkbox"),
		array(	"type" => "close"),
		array(	"type" => "close"),


		// OPTIN TEXT
		
		array(  "type" => "title",
				"name" => "Optin Box Controls",
				"desc" => "Edit the optin box text &amp; other controls."),

		array(	"type" => "row-open"),
		array(	"type" => "col-open"),
		array(	"name" => "Enter Headline",  
				"id" => $shortname."_headline",  
				"type" => "text",  
				"std" => "Enter the Headline"),

		array(	"name" => "Enter Sub-Headline",  
				"id" => $shortname."_subheadline",  
				"type" => "text",  
				"std" => "Enter the Sub-Headline"),
		array(	"type" => "close"),

		array(	"type" => "col-open"),
		array(	"name" => "Enter Description of Newsletter",  
				"id" => $shortname."_desc",  
				"type" => "textarea",  
				"std" => "Enter a catchy description of your awesome newsletter here."),
		array(	"type" => "close"),
		
		array(	"type" => "col-open"),
		array(	"name" => "Alert",  
				"type" => "alert"),
		array(	"type" => "close"),

		array(	"type" => "close"),
		
		
		// OPTIN TOGGLES
		
		array(	"type" => "row-last-open"),

		array(	"type" => "col-open"),
		array( 	"desc" => "Disable Header Optin Box",
				"id" => $shortname."_header_optin_toggle",
				"std" => "false",
				"type" => "checkbox"),


		array( 	"desc" => "Disable Content Optin Box",
				"id" => $shortname."_content_optin_toggle",
				"std" => "false",
				"type" => "checkbox"),
				

		array( 	"desc" => "Disable Single Page Sidebar Optin Box",
				"id" => $shortname."_single_optin_toggle",
				"std" => "false",
				"type" => "checkbox"),

		array(	"type" => "close"),
		array(	"type" => "close"),


		// FEATURED PRODUCT WIDGET CONTROLS

		array(  "type" => "title",
				"name" => "Affiliate Product Listing Widget",
				"desc" => "Activate/deactivate the products listing widget &amp; other controls."),


		array(	"type" => "row-open"),

		array(	"type" => "col-open"),
		array(	"name" => "Widget Title",  
				"id" => $shortname."_listing_title",  
				"type" => "text",  
				"std" => "Enter the widget title"),
		array(	"type" => "close"),

		
		array(	"type" => "col-open"),		
		array(	"name" => "Widget Sub-Title",  
				"id" => $shortname."_listing_sub_title",  
				"type" => "text",  
				"std" => "Enter the widget sub-title"),
		array(	"type" => "close"),

		array(	"type" => "close"),
		
		array(	"type" => "row-last-open"),
		
		array(	"type" => "col-open"),
		array( 	"desc" => "Enable Featured Products Listing",
				"id" => $shortname."_products_toggle",
				"std" => "false",
				"type" => "checkbox"),
		array(	"type" => "close"),

		array(	"type" => "close"),


		// ADMIN OPTIONS

		array(  "type" => "title",
				"name" => "Administration Options",
				"desc" => "Always remember to save your changes!"),

		array(	"type" => "row-open"),		
			array(  "type" => "submit"),
		array(	"type" => "close"),
	);


function add_admin() {
	global $themename, $shortname, $options, $skin_version;
	if ($_GET['page'] == basename(__FILE__)) {
        if ('save' == $_REQUEST['action']) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}

			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } 
			}
			header("Location: admin.php?page=skin_options.php&saved=true");
        } else if( 'reset' == $_REQUEST['action'] ) {

		foreach ($options as $value) {
			delete_option( $value['id'] ); 
		}
		header("Location: admin.php?page=skin_options.php&reset=true");
        }
    }
	add_submenu_page('thesis-options', $themename." Options", "".$themename." Options", 'edit_themes', basename(__FILE__), 'skin_admin');
}


function extra_css() {	/* ADD EXTRA COLORS HERE */
global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } }

switch ($mar_appearance_theme) {
	case "Red [Default]": ?>
		<link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/red.css" rel="stylesheet" />
    <?php break;
	case "Orange": ?>
		<link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/orange.css" rel="stylesheet" />
    <?php break;
	
	case "Blue": ?>
   	 <link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/blue.css" rel="stylesheet" />
    <?php break;

	case "Green": ?>
   	 <link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/green.css" rel="stylesheet" />
    <?php break; 
	}
}
	add_action('wp_head', 'extra_css');


function admin_css() { ?> 
	<link rel="stylesheet" type="text/css" media="all" href="<?php echo get_bloginfo(template_directory); ?>/custom/admin/style.css" />
<?php }
	add_action('admin_enqueue_scripts','admin_css');


function skin_admin() { global $themename, $shortname, $options, $skin_version, $logo_path, $skin_author, $author_url; ?>
	<div id="wrap">
		<div id="header">
			<h1><a href="admin.php?page=skin_options.php">Kolakube Skin Options</a></h1>
			<ul>
				<li><a href="http://kolakube.com/">Kolakube</a></li>
				<li><a href="http://kolakube.com/member/member.php">My Account</a></li>
				<li><a href="http://kolakube.com/support/">Support</a></li>
				<li><a href="http://kolakube.com/affiliates/">Make Money</a></li>
			</ul>
		</div>
		
		<div id="skin">
			<?php if ($_REQUEST['saved']) { ?>
				<div id="message" class="updated fade">
					<p>Options Updated! <a href="<?php echo bloginfo('url'); ?>">Check out your site &rarr;</a></p>
				</div>
			<?php } if ($_REQUEST['reset']) { ?>
    			<div id="message" class="updated fade">
    			<p>Options Reset! <a href="<?php echo bloginfo('url'); ?>">Check out your site &rarr;</a></p>
    			</div> 
			<?php } ?>
			<div id="meta">
				<img src="<?php echo get_bloginfo(template_directory); ?><?php echo $logo_path; ?>" />
				<div class="details">
					<h5><?php echo $themename; ?> <?php echo $skin_version; ?></h5>
					<span><em>by</em> <?php echo $skin_author; ?> <?php echo $author_url; ?></span>
				</div>
			</div>
		</div>
		
		<form method="post" class="kol">
			<?php foreach ($options as $value) { switch ($value['type']) {

			case "row-open": ?>
			<div class="row">
			<?php break;


			case "row-last-open": ?>
			<div class="row last">
			<?php break;


			case "close": ?>
			</div>
			<?php break;


			case "col-open": ?>
			<div class="col">
			<?php break;


			case "title": ?>
			<div class="title_bar">
				<h3><?php echo $value['name']; ?> <span><?php echo $value['desc']; ?></span></h3>
				<span class="left"></span>
				<span class="right"></span>
			</div>
			<?php break;
			
			
			case "alert": ?>
			<div id="alert">
				<h3>Input Code Notice</h3>
				<p><em>For now</em>, the only way to edit your input form (area where user inputs name &amp; email), is to copy and paste your optin code via FTP into <acronym>/custom/paste_optin.inc</acronym>.</p>
			</div>
			<?php break;
			
			
			case 'text': ?>
			<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label> 
			<p>
				<input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if (get_settings($value['id']) != "") { echo stripslashes(get_settings( $value['id'])); } else { echo $value['std']; } ?>" />
			</p>
			<?php break;


			case 'textarea': ?>
			<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label> 
			<p>
				<textarea name="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="30" rows="5"><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
			</p>
			<?php break;

			
			case 'select': ?> 					
			<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php foreach ($value['options'] as $option) { ?>
				<option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?>
				</option><?php } ?>
			</select>
			<?php break;


			case "checkbox":
			if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
				<div class="checkbox">
					<label style="margin: -0.3em 0 0.6em 0.4em" for="<?php echo $value['id']; ?>"><?php echo $value['desc']; ?></label>
					<input style="float: left" type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
				</div>
			<?php break;


			case "submit": ?>
			<p class="action">
				<input type="submit" class="save" name="submit" value="Save All Options" />
				<input type="hidden" name="action" value="save" />
			</p>
		</form>

		<form method="post" class="kol">
			<p class="action">
				<input name="reset" type="submit" class="reset" value="Reset Default Options" onClick="return confirm('Are you sure you want to reset the <?php echo $themename; ?> options?')" />
				<input type="hidden" name="action" value="reset" />
			</p>
		</form>
	</div> <!-- end #wrap -->
	<?php break;
} } }
	add_action('admin_menu', 'add_admin');