<?php
	$themename = "Velocity";
	$skin_version = "1.0";
	$shortname = "vel";
	$skin_author = "Alex Mangini, ";
	$author_url = "<a href='http://kolakube.com/'>Kolakube</a>";
	$logo_path = "/custom/admin/images/velocity_logo.png";
	$options = array (


		// AD MANAGER
		
		array(  "type" => "title",
				"name" => "Ad Manager",
				"desc" => "Add new advertisement banners to the homepage."),

		array(	"type" => "row-open"),
		array(	"type" => "col-open"),
		
		array(  "name" => "Advertisement 1",
				"id" => $shortname."_ad_one_link",
				"std" => "http://kolakube.com/skins/",
				"type" => "ad-link"),
		
		array(	"id" => $shortname."_ad_one_image",
			    "std" => get_bloginfo(template_directory)."/custom/admin/default/125x125-1.png",
				"type" => "ad-image"),
		
		array(	"type" => "close"),
		array(	"type" => "col-open"),

		array(  "name" => "Advertisement 2",
			  	"id" => $shortname."_ad_two_link",
				"std" => "http://kolakube.com/skins/",
				"type" => "ad-link"),
		
		array(	"id" => $shortname."_ad_two_image",
			    "std" => get_bloginfo(template_directory)."/custom/admin/default/125x125-2.png",
				"type" => "ad-image"),
				
		array(	"type" => "close"),
		array(	"type" => "col-open"),

		array(  "name" => "Advertisement 3",
				"id" => $shortname."_ad_three_link",
				"std" => "http://kolakube.com/skins/",
				"type" => "ad-link"),
		
		array(	"id" => $shortname."_ad_three_image",
			   	"std" => get_bloginfo(template_directory)."/custom/admin/default/125x125-3.png",
				"type" => "ad-image"),
				
		array(	"type" => "close"),
		array(	"type" => "close"),
		array(	"type" => "row-last-open"),
		array(	"type" => "col-open"),

		array(  "name" => "Advertisement 4",
				"id" => $shortname."_ad_four_link",
				"std" => "http://kolakube.com/skins/",
				"type" => "ad-link"),
		
		array(	"id" => $shortname."_ad_four_image",
			   	"std" => get_bloginfo(template_directory)."/custom/admin/default/125x125-4.png",
				"type" => "ad-image"),
				
		array(	"type" => "close"),
		array(	"type" => "close"),

		// ADMIN OPTIONS

		array(  "type" => "title",
				"name" => "Administration Options",
				"desc" => "Always remember to save your changes!"),
				
		array(	"type" => "row-open"),	
		array( 	"desc" => "Disable Ads",
				"id" => $shortname."_ads_toggle",
				"std" => "false",
				"type" => "checkbox"),

		array(  "type" => "submit"),
		array(	"type" => "close"),
	);


function add_admin() {
	global $themename, $shortname, $options, $skin_version;
	if ($_GET['page'] == basename(__FILE__)) {
        if ('save' == $_REQUEST['action']) {
			foreach ($options as $value) {
				update_option( $value['id'], $_REQUEST[ $value['id'] ] ); 
			}

			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } 
			}
			
			header("Location: admin.php?page=skin_options.php&saved=true");
        } else if( 'reset' == $_REQUEST['action'] ) {

		foreach ($options as $value) {
			delete_option( $value['id'] ); 
		}

		header("Location: admin.php?page=skin_options.php&reset=true");
        }
    }
	add_submenu_page('thesis-options', $themename." Options", "".$themename." Options", 'edit_themes', basename(__FILE__), 'skin_admin');
}


function admin_css() { ?> 
	<link rel="stylesheet" type="text/css" media="all" href="<?php echo get_bloginfo(template_directory); ?>/custom/admin/style.css" />
<?php }
	add_action('admin_enqueue_scripts','admin_css');


function skin_admin() { global $themename, $shortname, $options, $skin_version, $logo_path, $skin_author, $author_url; ?>
	<div id="wrap">
		<div id="header">
			<h1><a href="admin.php?page=skin_options.php">Kolakube Skin Options</a></h1>
			<ul>
				<li><a href="http://kolakube.com/">Kolakube</a></li>
				<li><a href="http://kolakube.com/member/member.php">My Account</a></li>
				<li><a href="http://kolakube.com/support/">Support</a></li>
				<li><a href="http://kolakube.com/affiliates/">Make Money</a></li>
			</ul>
		</div>
		
		<div id="skin">
			<?php if ($_REQUEST['saved']) { ?>
				<div id="message" class="updated fade">
					<p>Options Updated! <a href="<?php echo bloginfo('url'); ?>">Check out your site &rarr;</a></p>
				</div>
			<?php } if ($_REQUEST['reset']) { ?>
    			<div id="message" class="updated fade">
    			<p>Options Reset! <a href="<?php echo bloginfo('url'); ?>">Check out your site &rarr;</a></p>
    			</div> 
			<?php } ?>
			<div id="meta">
				<img src="<?php echo get_bloginfo(template_directory); ?><?php echo $logo_path; ?>" />
				<div class="details">
					<h5><?php echo $themename; ?> <?php echo $skin_version; ?></h5>
					<span><em>by</em> <?php echo $skin_author; ?> <?php echo $author_url; ?></span>
				</div>
			</div>
		</div>
		
		<form method="post" class="kol">
			<?php foreach ($options as $value) { switch ($value['type']) {


			case "title": ?>
			<div class="title_bar">
				<h3><?php echo $value['name']; ?> <span><?php echo $value['desc']; ?></span></h3>
				<span class="left"></span>
				<span class="right"></span>
			</div>
			<?php break;

			
			case 'select': ?> 					
			<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php foreach ($value['options'] as $option) { ?>
				<option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?>
				</option><?php } ?>
			</select>
			<?php break;


			case "checkbox":
			if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
			<div id="disable">
				<input type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
				<label for="<?php echo $value['id']; ?>"><?php echo $value['desc']; ?></label>
			</div>
			<?php break;


			case "row-open": ?>
			<div class="row">
			<?php break;


			case "row-last-open": ?>
			<div class="row last">
			<?php break;


			case "close": ?>
			</div>
			<?php break;


			case "col-open": ?>
			<div class="col">
			<?php break;


			case 'ad-link': ?>
			<h4><?php echo $value['name']; ?></h4>
			<p>Please enter the <strong>full</strong> <acronym title="Uniform Resource Locator">URL</acronym> of the target link &amp; image location below.</p>
			<p class="input_format">
				<label for="<?php echo $value['id']; ?>">Ad Link</label><br/>
				<input style="width:250px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'] )); } else { echo stripslashes($value['std']); } ?>" />
			</p>
			<?php break;


			case 'ad-image':?>
			<p class="input_format">
				<label for="<?php echo $value['id']; ?>">Image Location</label><br />
				<input style="width:250px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'] )); } else { echo stripslashes($value['std']); } ?>" />
			</p>
			<p>
				Preview: <br />
				<img style="width: 125px; height: 125px;" alt="" src="<?php if(get_settings( $value['id']) != "") { echo stripslashes(get_settings($value['id'])); } else { echo stripslashes($value['std']); } ?>" />
			</p>
			<?php break;


			case "submit": ?>
			<p class="action">
				<input type="submit" class="save" name="submit" value="Save All Options" />
				<input type="hidden" name="action" value="save" />
			</p>
		</form>

		<form method="post" class="kol">
			<p class="action">
				<input name="reset" type="submit" class="reset" value="Reset Default Options" onClick="return confirm('Are you sure you want to reset the <?php echo $themename; ?> options?')" />
				<input type="hidden" name="action" value="reset" />
			</p>
		</form>
	</div> <!-- end #wrap -->
	<?php break;
} } }
	add_action('admin_menu', 'add_admin');