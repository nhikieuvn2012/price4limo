<?php

// Using hooks is absolutely the smartest, most bulletproof way to implement things like plugins,
// custom design elements, and ads. You can add your hook calls below, and they should take the 
// following form:
// add_action('thesis_hook_name', 'function_name');
// The function you name above will run at the location of the specified hook. The example
// hook below demonstrates how you can insert Thesis' default recent posts widget above
// the content in Sidebar 1:
// add_action('thesis_hook_before_sidebar_1', 'thesis_widget_recent_posts');

// Delete this line, including the dashes to the left, and add your hooks in its place.

/**
 * function custom_bookmark_links() - outputs an HTML list of bookmarking links
 * NOTE: This only works when called from inside the WordPress loop!
 * SECOND NOTE: This is really just a sample function to show you how to use custom functions!
 *
 * @since 1.0
 * @global object $post
*/

require_once('admin/skin_options.php');
require_once('admin/widgets.php');


function slider_js() { if(is_front_page()) { ?>     <!-- Call .js files for Slider -->
	<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/custom/js/slider.js"></script><script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/custom/js/bx-slider.js"></script>
<?php } }
	add_action('thesis_hook_after_html', 'slider_js');


remove_action('thesis_hook_before_header','thesis_nav_menu');
add_action('thesis_hook_after_title','thesis_nav_menu');


/*-------------------------------------------------------------------------------------------------------
   HOMEPAGE
-------------------------------------------------------------------------------------------------------*/
	
function feat_box() {
	global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } { if(is_front_page()) { ?>
	<?php if ($vel_ads_toggle != "false") { ?>
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/custom/admin/feat_box.css" type="text/css" media="screen, projection" />
	<?php } ?>
<?php } } }
	add_action('wp_head', 'feat_box');


function slider() { if(is_front_page()) { ?>
	<div class="full_width sliderbg">
		<div class="page">
			<ul id="slider">
				<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Slider') ){ ?>
					<?php include('admin/slider_default.inc'); ?>
				<? } ?>
			</ul>
		</div>
	</div>
<?php } }
	add_action('thesis_hook_before_content_area', 'slider');
		register_sidebar(array('name'=>'Homepage Slider', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li class="space">', 'after_widget'  => '</li>',));


function home_template() {
	global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } } { if(is_front_page()) { ?>
	<?php include('home_template.php'); ?>
<?php } } }
	remove_action('thesis_hook_custom_template', 'thesis_custom_template_sample');
	add_action('thesis_hook_custom_template', 'home_template');
	
	
remove_action('thesis_hook_after_post', 'thesis_comments_link');


function sidebar_1_top() { ?>
	<span class="top"></span>
<?php }
	add_action('thesis_hook_after_sidebar_1', 'sidebar_1_top');
	

/*-------------------------------------------------------------------------------------------------------
   FOOTER
-------------------------------------------------------------------------------------------------------*/

function footer() { ?>
	<ul>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 1') ){ ?>
		<li>
			<h3>Custom Widget 1</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 1</em></p>
		</li>
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 2') ){ ?>
		<li>
			<h3>Custom Widget 2</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 2</em></p>
		</li>		
		<? } ?>
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Column 3') ){ ?>
		<li class="last">
			<h3>Custom Widget 3</h3>
		<p>This widget is completely customizable and can be controlled via the Widgets Panel in <em>Admin &rarr; Appearance &rarr; Widgets &rarr; Footer Column 3</em></p>
		</li>		
		<? } ?>
	</ul>
	<div id="copyright">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Copyright') ){ ?>
		<p>Enter your own copyright text here using a <em>text widget</em>.</p>
		<? } ?>
		<!-- Make sure you have the proper licensing before deleting either copyrights -->
		<p>Built on <a href="http://diythemes.com/thesis/">Thesis</a>. <a href="http://kolakube.com/">Thesis skins by Kolakube</a></p>
		<!-- / Make sure you have the proper licensing before deleting either copyrights -->
	</div>
<?php }
	add_action('thesis_hook_footer', 'footer');
	remove_action('thesis_hook_footer', 'thesis_attribution');
	register_sidebar(array('name'=>'Footer Column 1', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Column 2', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li>', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Column 3', 'before_title' => '<h3>', 'after_title' => '</h3>', 'before_widget' => '<li class="last">', 'after_widget'  => '</li>'));
	register_sidebar(array('name'=>'Footer Copyright', 'before_widget' => '', 'after_widget'  => ''));

?>