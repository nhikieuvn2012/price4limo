<?php

class slider_widget extends WP_Widget {
	function slider_widget() {	/* WIDGET PROCESSES */
		$widget_ops = array('classname' => 'widget_bu_text', 'description' => 'Featured article + image slider (homepage only)' );
		$this->WP_Widget('slider_widget', 'Featured Slider Content [VEL]', $widget_ops);
	}

	function form($instance) {	/* ADMIN OPTIONS FORMS */
		$instance = wp_parse_args((array) $instance, array( 'title' => '', 'url' => '', 'img' => '',  'entry_content' => '' ) );
		$title = strip_tags($instance['title']);
		$url = $instance['url'];
		$img = $instance['img'];
		$entry_content = $instance['entry_content'];
	?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>	
		<p><label for="<?php echo $this->get_field_id('url'); ?>">Link: <input class="widefat" id="<?php echo $this->get_field_id('url'); ?>" name="<?php echo $this->get_field_name('url'); ?>" type="text" value="<?php echo attribute_escape($url); ?>" /></label></p>	
		<p><label for="<?php echo $this->get_field_id('img'); ?>">Featured Image URL: <input class="widefat" id="<?php echo $this->get_field_id('img'); ?>" name="<?php echo $this->get_field_name('img'); ?>" type="text" value="<?php echo attribute_escape($img); ?>" /></label></p>
		<p><label for="<?php echo $this->get_field_id('entry_content'); ?>">Paragraph Text: <textarea class="widefat" id="<?php echo $this->get_field_id('entry_content'); ?>" name="<?php echo $this->get_field_name('entry_content'); ?>" type="text" cols="20" rows="16"><?php echo attribute_escape($entry_content); ?></textarea></label></p>
	<?php }
	
	function update($new_instance, $old_instance) {	/* SAVE OPTIONS */
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['url'] = $new_instance['url'];
		$instance['img'] = $new_instance['img'];
		$instance['entry_content'] = $new_instance['entry_content'];
		return $instance;
	}

	function widget($args, $instance) {	/* WIDGET OUTPUT */
		extract($args, EXTR_SKIP);
		echo $before_widget;
		$title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
		$url = empty($instance['url']) ? '' : apply_filters('widget_title', $instance['url']);
		$img = empty($instance['img']) ? '' : apply_filters('widget_title', $instance['img']);
		$entry_content = empty($instance['entry_content']) ? '' : apply_filters('widget_entry_content', $instance['entry_content']);

		if (!empty($instance['img'])) { 
			echo '<img src="' . $img . '" alt="' . $title . '" />';
		} else { echo ''; };

		if (!empty($instance['url'])) { 
			echo $before_title . '<a href="' . $url . '">' . $title . '</a>' . $after_title;
		} else { echo $before_title . $title . $after_title; };
		echo '<p>' . $entry_content . '</p>';
		echo $after_widget;
	}
}
register_widget('slider_widget');
?>