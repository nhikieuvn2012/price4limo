		<div id="latest">
			<h4>Latest Posts</h4>
			<span id="title">From the Blog</span>
			<ul>
				<?php $the_query = new WP_Query('showposts=5&orderby=post_date&order=desc'); while ($the_query->have_posts()) : $the_query->the_post(); ?>
				<li>
					<h3><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
					<span class="date"><em>on</em> <?php the_date(); ?></span>
					<?php the_excerpt(); ?>
				</li>				
				<?php endwhile; ?>
				<?php wp_reset_query(); ?>	
    		</ul>
		</div>

		<?php if ($vel_ads_toggle != "true") { ?>
			<div id="ads">
				<ul>
					<li><a href="<?php echo $vel_ad_one_link; ?>"><img src="<?php echo $vel_ad_one_image; ?>" alt="" /></a></li>
					<li><a href="<?php echo $vel_ad_two_link; ?>"><img src="<?php echo $vel_ad_two_image; ?>" alt="" /></a></li>
					<li><a href="<?php echo $vel_ad_three_link; ?>"><img src="<?php echo $vel_ad_three_image; ?>" alt="" /></a></li>
					<li><a href="<?php echo $vel_ad_four_link; ?>"><img src="<?php echo $vel_ad_four_image; ?>" alt="" /></a></li>
				</ul>
				<span class="top"></span>
			</div>
		<?php } ?>

	<div id="feat_box">
		<div class="post_box">
			<div class="format_text">
				<?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
						<h2><?php the_title(); ?></h2>
						<?php the_content(); ?>
					<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>