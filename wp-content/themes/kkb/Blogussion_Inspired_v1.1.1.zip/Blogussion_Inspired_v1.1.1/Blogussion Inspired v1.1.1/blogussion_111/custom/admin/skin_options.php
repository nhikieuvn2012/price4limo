<?php

add_action('admin_enqueue_scripts', 'blogussion_admin_css'); // Add our admin CSS

function blogussion_admin_css() { ?> <link rel="stylesheet" type='text/css' media='all' href="<?php echo get_bloginfo(template_directory); ?>/custom/admin/skin_options_style.css?for=blogussion" /> 
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript">

function addFormField() {
	var id = document.getElementById("id").value;
	$("#divTxt").append("<p class='form_input bu_children' id='row" + id + "'><label for='nav_one_title_" + id + "'>Title: &nbsp;&nbsp;<input type='text' name='txt[]' id='nav_one_title_" + id + "'><label for='nav_one_link_" + id + "'>Link: &nbsp;&nbsp;<input type='text' name='txt[]' id='nav_one_link_" + id + "'><a href='#' onClick='removeFormField(\"#row" + id + "\"); return false;'>Remove</a><p>");
	
	id = (id - 1) + 2;
	document.getElementById("id").value = id;
}

function removeFormField(id) {
	$(id).remove();
}
</script>

<?php }

	$themename = "Blogussion";
	$skin_version = "1.1.1 (Kolakube built)";
	$shortname = "bu";
	$options = array (
					  
		// Appearance
		
		array(  "type" => "open-column"),
		array(  "name" => "Skin Appearance",
				"type" => "open-module"),
		array(  "name" => "Color Scheme",
			    "desc" => "Choose a color scheme:",
				"type" => "open-sub"),
		
		array(  "id" => $shortname."_appearance_theme",
				"options" => array("Blue [Default]", "Green", "Orange", "Gray"),
				"std" => "Blue [Default]",
				"type" => "select"),
		
		array(  "type" => "close-sub"),		
		array(  "type" => "close-module"),
		array(  "type" => "close-column"),
		
		// Second Nav
		
		array(  "type" => "open-column"),
		array(  "name" => "2nd Navigation - Top Level",
				"type" => "open-module"),
		
		array(  "name" => "Navigation Item 1",
			    "desc" => "Set up Navigation Item 1 with a Title, description, and title- or disable it altogether.",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_second_nav_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => 'Nav #1'),
		array(  "id" => $shortname."_second_nav_one_description",
				"type" => "text",
				"desc" => "Short Description",
				"std" => 'Short Desc.'),
		array(  "id" => $shortname."_second_nav_one_link",
				"type" => "text",
				"desc" => "Link (full URL)",
				"std" => ''),
		array(  "desc" => "Disable Navigation Item 1?",
				"id" => $shortname."_second_nav_one_toggle",
				"std" => "false",
				"type" => "checkbox"),
		
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 2",
			    "desc" => "Set up Navigation Item 2 with a Title, description, and title- or disable it altogether.",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_second_nav_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => 'Nav #2'),
		array(  "id" => $shortname."_second_nav_two_description",
				"type" => "text",
				"desc" => "Short Description",
				"std" => 'Short Desc.'),
		array(  "id" => $shortname."_second_nav_two_link",
				"type" => "text",
				"desc" => "Link (full URL)",
				"std" => ''),
		array(  "desc" => "Disable Navigation Item 2?",
				"id" => $shortname."_second_nav_two_toggle",
				"std" => "false",
				"type" => "checkbox"),
		
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 3",
			    "desc" => "Set up Navigation Item 3 with a Title, description, and title- or disable it altogether.",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_second_nav_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => 'Nav #3'),
		array(  "id" => $shortname."_second_nav_three_description",
				"type" => "text",
				"desc" => "Short Description",
				"std" => 'Short Desc.'),
		array(  "id" => $shortname."_second_nav_three_link",
				"type" => "text",
				"desc" => "Link (full URL)",
				"std" => ''),
		array(  "desc" => "Disable Navigation Item 3?",
				"id" => $shortname."_second_nav_three_toggle",
				"std" => "false",
				"type" => "checkbox"),
		
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 4",
			    "desc" => "Set up Navigation Item 4 with a Title, description, and title- or disable it altogether.",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_second_nav_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => 'Nav #4'),
		array(  "id" => $shortname."_second_nav_four_description",
				"type" => "text",
				"desc" => "Short Description",
				"std" => 'Short Desc.'),
		array(  "id" => $shortname."_second_nav_four_link",
				"type" => "text",
				"desc" => "Link (full URL)",
				"std" => ''),
		array(  "desc" => "Disable Navigation Item 4?",
				"id" => $shortname."_second_nav_four_toggle",
				"std" => "false",
				"type" => "checkbox"),
		
		array(  "type" => "close-sub"),

		array(  "name" => "Navigation Item 5",
			    "desc" => "Set up Navigation Item 5 with a Title, description, and title- or disable it altogether.",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_second_nav_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => 'Nav #5'),
		array(  "id" => $shortname."_second_nav_five_description",
				"type" => "text",
				"desc" => "Short Description",
				"std" => 'Short Desc.'),
		array(  "id" => $shortname."_second_nav_five_link",
				"type" => "text",
				"desc" => "Link (full URL)",
				"std" => ''),
		array(  "desc" => "Disable Navigation Item 5?",
				"id" => $shortname."_second_nav_five_toggle",
				"std" => "false",
				"type" => "checkbox"),
		
		array(  "type" => "close-sub"),

		array(  "type" => "close-module"),
		array(  "type" => "close-column"),
		
		// Second Nav Child
		
		array(  "type" => "open-column"),
		array(  "name" => "2nd Navigation - Child Level",
				"type" => "open-module"),
		
		array(  "name" => "Navigation Item 1 Children",
			    "desc" => "Add drop down links for Navigation Item 1. Make sure to save after adding your options.<br/><br/>Link 1:",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_one_child_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_one_child_one_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 2:',
				"type" => "textfill"),
		array(  "id" => $shortname."_one_child_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_one_child_two_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 3:',
				"type" => "textfill"),
		array(  "id" => $shortname."_one_child_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_one_child_three_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 4:',
				"type" => "textfill"),
		array(  "id" => $shortname."_one_child_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_one_child_four_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 5:',
				"type" => "textfill"),
		array(  "id" => $shortname."_one_child_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_one_child_five_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 2 Children",
			    "desc" => "Add drop down links for Navigation Item 2. Make sure to save after adding your options.<br/><br/>Link 1:",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_two_child_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_two_child_one_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 2:',
				"type" => "textfill"),
		array(  "id" => $shortname."_two_child_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_two_child_two_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 3:',
				"type" => "textfill"),
		array(  "id" => $shortname."_two_child_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_two_child_three_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 4:',
				"type" => "textfill"),
		array(  "id" => $shortname."_two_child_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_two_child_four_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 5:',
				"type" => "textfill"),
		array(  "id" => $shortname."_two_child_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_two_child_five_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 3 Children",
			    "desc" => "Add drop down links for Navigation Item 3. Make sure to save after adding your options.<br/><br/>Link 1:",
				"type" => "open-sub"),
		
				array(  "id" => $shortname."_three_child_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_three_child_one_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 2:',
				"type" => "textfill"),
		array(  "id" => $shortname."_three_child_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_three_child_two_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 3:',
				"type" => "textfill"),
		array(  "id" => $shortname."_three_child_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_three_child_three_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 4:',
				"type" => "textfill"),
		array(  "id" => $shortname."_three_child_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_three_child_four_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 5:',
				"type" => "textfill"),
		array(  "id" => $shortname."_three_child_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_three_child_five_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "type" => "close-sub"),
		
		array(  "name" => "Navigation Item 4 Children",
			    "desc" => "Add drop down links for Navigation Item 4. Make sure to save after adding your options.<br/><br/>Link 1:",
				"type" => "open-sub"),
		
						array(  "id" => $shortname."_four_child_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_four_child_one_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 2:',
				"type" => "textfill"),
		array(  "id" => $shortname."_four_child_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_four_child_two_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 3:',
				"type" => "textfill"),
		array(  "id" => $shortname."_four_child_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_four_child_three_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 4:',
				"type" => "textfill"),
		array(  "id" => $shortname."_four_child_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_four_child_four_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 5:',
				"type" => "textfill"),
		array(  "id" => $shortname."_four_child_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_four_child_five_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "type" => "close-sub"),


		array(  "name" => "Navigation Item 5 Children",
			    "desc" => "Add drop down links for Navigation Item 5. Make sure to save after adding your options.<br/><br/>Link 1:",
				"type" => "open-sub"),
	
		array(  "id" => $shortname."_five_child_one_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_five_child_one_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 2:',
				"type" => "textfill"),
		array(  "id" => $shortname."_five_child_two_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_five_child_two_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 3:',
				"type" => "textfill"),
		array(  "id" => $shortname."_five_child_three_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_five_child_three_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 4:',
				"type" => "textfill"),
		array(  "id" => $shortname."_five_child_four_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_five_child_four_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		
		array(  "desc" => '<br/>Link 5:',
				"type" => "textfill"),
		array(  "id" => $shortname."_five_child_five_title",
				"type" => "text",
				"desc" => "Title",
				"std" => ''),
		array(  "id" => $shortname."_five_child_five_link",
				"type" => "text",
				"desc" => "Link",
				"std" => ''),
		array(  "type" => "close-sub"),
		

		array(  "type" => "close-module"),
		
		array(  "type" => "submit"),
		array(  "type" => "close-column")
	);

function extra_css() {
global $options; foreach ($options as $value) { if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); } }

switch ($bu_appearance_theme) {
	case "Blue [Default]": ?>
		<link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/blue.css" rel="stylesheet" />
    <?php break;
	case "Green": ?>
		<link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/green.css" rel="stylesheet" />
    <?php break;
	
	case "Orange": ?>
   	 <link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/orange.css" rel="stylesheet" />
    <?php break; 
    
	case "Gray": ?>
   	 <link media="screen, projection" type="text/css" href="<?php bloginfo('template_url'); ?>/custom/colors/gray.css" rel="stylesheet" />
    <?php break; 
	
	}
}
	
function blogussion_add_admin() {
	global $themename, $shortname, $options, $skin_version;
	
	if ( $_GET['page'] == basename(__FILE__) ) {

        if ( 'save' == $_REQUEST['action'] ) {
			

                foreach ($options as $value) {
                    update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }

                foreach ($options as $value) {
                    if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
                header("Location: admin.php?page=skin_options.php&saved=true");
                

        } else if( 'reset' == $_REQUEST['action'] ) {

            foreach ($options as $value) {
                delete_option( $value['id'] ); }
				
            header("Location: admin.php?page=skin_options.php&reset=true");
            

        }
    }

    add_submenu_page('thesis-options', $themename." Options", "".$themename." Options", 'edit_themes', basename(__FILE__), 'blogussion_admin');

}

function blogussion_admin() {

    global $themename, $shortname, $options, $skin_version;

?>
<div class="wrap blogussion" id="thesis_options">
<span id="thesis_version">
You are rocking <a href="http://kolakube.com/skins/blogussion/">Blogussion</a> version <strong><?php echo $skin_version; ?></strong>
</span>
<h2>
Blogussion Options<a id="master_switch" title="Big Ass Toggle Switch" href="">
<span class="pos">+</span>
<span class="neg" style="display: none;">–</span>
</a>
</h2>

<ul id="thesis_links">
		<li><a href="http://diythemes.com/answers/">DIYthemes Answers</a></li>
		<li><a href="http://diythemes.com/forums/">Support Forums</a></li>
		<li><a href="http://diythemes.com/thesis/rtfm/">User’s Guide</a></li>
		<li><a href="https://diythemes.com/affiliate-program/">Sell Thesis, Earn Cash!</a></li>
		<li><a href="http://diythemes.com/dev/">Thesis Dev Blog</a></li>
</ul>

	<?php    if ( $_REQUEST['saved'] ) { ?> <div id="message" class="updated fade"><p>Options Updated! <a href="<?php echo bloginfo('url'); ?>">Check out your site →</a></p></div><?php }
    if ( $_REQUEST['reset'] ) { ?> <div id="message" class="updated fade"><p>Options Reset! <a href="<?php echo bloginfo('url'); ?>">Check out your site →</a></p></div> 
<?php } ?>

<form method="post">

<?php foreach ($options as $value) {
switch ( $value['type'] ) {

case "open-column":
?>
<div class="options_column">


<?php break;

case "close-column": ?>
</div>
<?php break;


case "close-module": ?>
</div>
<?php break;

case "open-module": ?>
<div id="document-<?php echo $value['name']; ?>" class="options_module">
<h3><?php echo $value['name']; ?></h3>
<?php  break;


case 'open-sub': ?>
<div class="module_subsection">
<h4 class="module_switch"><a title="Show/hide additional information" href=""><span class="pos">+</span><span class="neg" style="display: none;">–</span></a><?php echo $value['name']; ?></h4>
<div class="more_info" style="display: block;">
<p><?php echo $value['desc']; ?></p> 
<?php break; 


case 'close-sub': ?>
</div></div>
<?php break;


case 'select': ?> 					
<select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php foreach ($value['options'] as $option) { ?><option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option><?php } ?></select>
<?php break;


case 'text': ?>               
	    <p class="form_input add_margin">
	<input style="width:250px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'] )); } else { echo stripslashes($value['std']); } ?>" /><label for="<?php echo $value['id']; ?>"><?php echo $value['desc']; ?></label></p>
<?php break;


case 'children': ?>            

<p><a href="#" onClick="addFormField(); return false;">Add</a></p>
<form action="#" method="get" id="form1">
<input type="hidden" id="id" value="1">
<div id="divTxt"></div>
</form>

<?php break;


case 'textarea': ?>
<textarea name="<?php echo $value['id']; ?>" style="width:250px; height:200px;" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'] )); } else { echo stripslashes($value['std']); } ?></textarea><label for="<?php echo $value['id']; ?>"><?php echo $value['desc']; ?></label>
<?php break;


case "checkbox":
if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
	<ul><li><input type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
						<label for="<?php echo $value['id']; ?>"><?php echo $value['desc']; ?></label></li></ul>
<?php break;	


case 'textfill': ?>
<p><?php echo $value['desc']; ?></p>
<?php break;

case "submit":
?>
	<div class="options_module button_module">
		<input type="submit" class="save_button" id="design_submit" name="submit" value="<?php thesis_save_button_text(true); ?>" />
	</div>
<input type="hidden" name="action" value="save" />
</form>
<form method="post">
<p class="submit submitbu">
<input name="reset" type="submit" value="Reset Blogussion to Default*" onClick="return confirm('Are you sure you want to reset Blogussion options?')" />
<input type="hidden" name="action" value="reset" />
</p>
</form>
<?php break;
		} 
	}
}

add_action('admin_menu', 'blogussion_add_admin');